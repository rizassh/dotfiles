vim.g.mapleader = " "
vim.g.maplocalleader = " "
vim.g.have_nerd_font = false
vim.g.loaded_python3_provider = 0

-- [[ Options ]]
vim.o.number = true
vim.o.relativenumber = false
vim.o.mouse = "a"
vim.o.showmode = false
vim.schedule(function()
	vim.o.clipboard = "unnamedplus"
end)
vim.o.breakindent = true
vim.o.undofile = true
vim.o.ignorecase = true
vim.o.smartcase = true
vim.o.signcolumn = "yes"
vim.o.updatetime = 250
vim.o.timeoutlen = 300
vim.o.splitright = true
vim.o.splitbelow = true
vim.o.list = true
vim.opt.listchars = { tab = "» ", trail = "·", nbsp = "␣" }
vim.o.inccommand = "split"
vim.o.cursorline = true
vim.o.scrolloff = 10
vim.o.confirm = true
vim.o.tabstop = 4
vim.o.shiftwidth = 4
vim.o.expandtab = true

local is_windows = vim.uv.os_uname().sysname == "Windows_NT"
local tbl_unpack = table.unpack or unpack

-- [[ Keymaps ]]
vim.keymap.set("n", "<Esc>", "<cmd>nohlsearch<CR>")
vim.keymap.set("n", "<leader>q", vim.diagnostic.setloclist, { desc = "Open diagnostic [Q]uickfix list" })
vim.keymap.set("t", "<Esc><Esc>", "<C-\\><C-n>", { desc = "Exit terminal mode" })
vim.keymap.set("n", "<C-h>", "<C-w><C-h>", { desc = "Move focus to the left window" })
vim.keymap.set("n", "<C-l>", "<C-w><C-l>", { desc = "Move focus to the right window" })
vim.keymap.set("n", "<C-j>", "<C-w><C-j>", { desc = "Move focus to the lower window" })
vim.keymap.set("n", "<C-k>", "<C-w><C-k>", { desc = "Move focus to the upper window" })

-- [[ Autocommands ]]
vim.api.nvim_create_autocmd("TextYankPost", {
	desc = "Highlight when yanking (copying) text",
	group = vim.api.nvim_create_augroup("kickstart-highlight-yank", { clear = true }),
	callback = function()
		vim.hl.on_yank()
	end,
})

-- [[ Install lazy.nvim ]]
local lazypath = vim.fn.stdpath("data") .. "/lazy/lazy.nvim"
if not (vim.uv or vim.loop).fs_stat(lazypath) then
	local lazyrepo = "https://github.com/folke/lazy.nvim.git"
	local out = vim.fn.system({ "git", "clone", "--filter=blob:none", "--branch=stable", lazyrepo, lazypath })
	if vim.v.shell_error ~= 0 then
		error("Error cloning lazy.nvim:\n" .. out)
	end
end
---@type vim.Option
local rtp = vim.opt.rtp
rtp:prepend(lazypath)

-- [[ Plugins ]]
require("lazy").setup({
	"NMAC427/guess-indent.nvim",

	{ -- Git signs in the gutter
		"lewis6991/gitsigns.nvim",
		opts = {
			signs = {
				add = { text = "+" },
				change = { text = "~" },
				delete = { text = "_" },
				topdelete = { text = "‾" },
				changedelete = { text = "~" },
			},
		},
	},

	{ -- Shows pending keybinds
		"folke/which-key.nvim",
		event = "VimEnter",
		opts = {
			delay = 0,
			icons = {
				mappings = vim.g.have_nerd_font,
				keys = vim.g.have_nerd_font and {} or {
					Up = "<Up> ",
					Down = "<Down> ",
					Left = "<Left> ",
					Right = "<Right> ",
					C = "<C-…> ",
					M = "<M-…> ",
					D = "<D-…> ",
					S = "<S-…> ",
					CR = "<CR> ",
					Esc = "<Esc> ",
					ScrollWheelDown = "<ScrollWheelDown> ",
					ScrollWheelUp = "<ScrollWheelUp> ",
					NL = "<NL> ",
					BS = "<BS> ",
					Space = "<Space> ",
					Tab = "<Tab> ",
					F1 = "<F1>",
					F2 = "<F2>",
					F3 = "<F3>",
					F4 = "<F4>",
					F5 = "<F5>",
					F6 = "<F6>",
					F7 = "<F7>",
					F8 = "<F8>",
					F9 = "<F9>",
					F10 = "<F10>",
					F11 = "<F11>",
					F12 = "<F12>",
				},
			},
			spec = {
				{ "<leader>s", group = "[S]earch" },
				{ "<leader>t", group = "[T]oggle" },
				{ "<leader>h", group = "Git [H]unk", mode = { "n", "v" } },
			},
		},
	},

	{ -- Fuzzy finder
		"nvim-telescope/telescope.nvim",
		event = "VimEnter",
		dependencies = {
			"nvim-lua/plenary.nvim",
			{
				"nvim-telescope/telescope-fzf-native.nvim",
				build = "make",
				cond = function()
					return vim.fn.executable("make") == 1
				end,
			},
			{ "nvim-telescope/telescope-ui-select.nvim" },
			{ "nvim-tree/nvim-web-devicons", enabled = vim.g.have_nerd_font },
		},
		config = function()
			require("telescope").setup({
				extensions = {
					["ui-select"] = {
						require("telescope.themes").get_dropdown(),
					},
				},
			})
			pcall(require("telescope").load_extension, "fzf")
			pcall(require("telescope").load_extension, "ui-select")

			local builtin = require("telescope.builtin")
			vim.keymap.set("n", "<leader>sh", builtin.help_tags, { desc = "[S]earch [H]elp" })
			vim.keymap.set("n", "<leader>sk", builtin.keymaps, { desc = "[S]earch [K]eymaps" })
			vim.keymap.set("n", "<leader>sf", builtin.find_files, { desc = "[S]earch [F]iles" })
			vim.keymap.set("n", "<leader>ss", builtin.builtin, { desc = "[S]earch [S]elect Telescope" })
			vim.keymap.set("n", "<leader>sw", builtin.grep_string, { desc = "[S]earch current [W]ord" })
			vim.keymap.set("n", "<leader>sg", builtin.live_grep, { desc = "[S]earch by [G]rep" })
			vim.keymap.set("n", "<leader>sd", builtin.diagnostics, { desc = "[S]earch [D]iagnostics" })
			vim.keymap.set("n", "<leader>sr", builtin.resume, { desc = "[S]earch [R]esume" })
			vim.keymap.set("n", "<leader>s.", builtin.oldfiles, { desc = '[S]earch Recent Files ("." for repeat)' })
			vim.keymap.set("n", "<leader><leader>", builtin.buffers, { desc = "[ ] Find existing buffers" })

			vim.keymap.set("n", "<leader>/", function()
				builtin.current_buffer_fuzzy_find(require("telescope.themes").get_dropdown({
					winblend = 10,
					previewer = false,
				}))
			end, { desc = "[/] Fuzzily search in current buffer" })

			vim.keymap.set("n", "<leader>s/", function()
				builtin.live_grep({
					grep_open_files = true,
					prompt_title = "Live Grep in Open Files",
				})
			end, { desc = "[S]earch [/] in Open Files" })

			vim.keymap.set("n", "<leader>sn", function()
				builtin.find_files({ cwd = vim.fn.stdpath("config") })
			end, { desc = "[S]earch [N]eovim files" })
		end,
	},

	-- LSP Plugins
	{
		"folke/lazydev.nvim",
		ft = "lua",
		opts = {
			library = {
				{ path = "${3rd}/luv/library", words = { "vim%.uv" } },
			},
		},
	},
	{
		"neovim/nvim-lspconfig",
		dependencies = {
			{ "mason-org/mason.nvim", opts = {} },
			"WhoIsSethDaniel/mason-tool-installer.nvim",
			{ "j-hui/fidget.nvim", opts = {} },
			"saghen/blink.cmp",
		},
		config = function()
			local lsp_attach_group = vim.api.nvim_create_augroup("kickstart-lsp-attach", { clear = true })
			local lsp_highlight_group = vim.api.nvim_create_augroup("kickstart-lsp-highlight", { clear = false })
			local lsp_detach_group = vim.api.nvim_create_augroup("kickstart-lsp-detach", { clear = true })

			---@param client vim.lsp.Client
			---@param method vim.lsp.protocol.Method
			---@param bufnr? integer
			---@return boolean
			local function client_supports_method(client, method, bufnr)
				return client:supports_method(method, bufnr)
			end

			local function buffer_has_highlight_client(bufnr)
				for _, client in ipairs(vim.lsp.get_clients({ bufnr = bufnr })) do
					if
						client_supports_method(client, vim.lsp.protocol.Methods.textDocument_documentHighlight, bufnr)
					then
						return true
					end
				end

				return false
			end

			vim.api.nvim_create_autocmd("LspDetach", {
				group = lsp_detach_group,
				callback = function(event)
					if not vim.api.nvim_buf_is_valid(event.buf) or buffer_has_highlight_client(event.buf) then
						return
					end

					vim.lsp.util.buf_clear_references(event.buf)
					vim.api.nvim_clear_autocmds({ group = lsp_highlight_group, buffer = event.buf })
					vim.b[event.buf].lsp_highlight_autocmds_enabled = nil
				end,
			})

			vim.api.nvim_create_autocmd("LspAttach", {
				group = lsp_attach_group,
				callback = function(event)
					local map = function(keys, func, desc, mode)
						mode = mode or "n"
						vim.keymap.set(mode, keys, func, { buffer = event.buf, desc = "LSP: " .. desc })
					end

					map("grn", vim.lsp.buf.rename, "[R]e[n]ame")
					map("gra", vim.lsp.buf.code_action, "[G]oto Code [A]ction", { "n", "x" })
					map("grr", require("telescope.builtin").lsp_references, "[G]oto [R]eferences")
					map("gri", require("telescope.builtin").lsp_implementations, "[G]oto [I]mplementation")
					map("grd", require("telescope.builtin").lsp_definitions, "[G]oto [D]efinition")
					map("grD", vim.lsp.buf.declaration, "[G]oto [D]eclaration")
					map("gO", require("telescope.builtin").lsp_document_symbols, "Open Document Symbols")
					map("gW", require("telescope.builtin").lsp_dynamic_workspace_symbols, "Open Workspace Symbols")
					map("grt", require("telescope.builtin").lsp_type_definitions, "[G]oto [T]ype Definition")
					map("gh", function()
						local params = { uri = vim.uri_from_bufnr(0) }
						vim.lsp.buf_request(0, "textDocument/switchSourceHeader", params, function(_, result)
							if result then
								vim.cmd.edit(vim.uri_to_fname(result))
							end
						end)
					end, "Switch [H]eader/Source")

					local client = vim.lsp.get_client_by_id(event.data.client_id)
					if
						client
						and client_supports_method(
							client,
							vim.lsp.protocol.Methods.textDocument_documentHighlight,
							event.buf
						)
					then
						if not vim.b[event.buf].lsp_highlight_autocmds_enabled then
							vim.api.nvim_create_autocmd({ "CursorHold", "CursorHoldI" }, {
								buffer = event.buf,
								group = lsp_highlight_group,
								callback = vim.lsp.buf.document_highlight,
							})

							vim.api.nvim_create_autocmd({ "CursorMoved", "CursorMovedI" }, {
								buffer = event.buf,
								group = lsp_highlight_group,
								callback = vim.lsp.buf.clear_references,
							})

							vim.b[event.buf].lsp_highlight_autocmds_enabled = true
						end
					end

					if
						client
						and client_supports_method(client, vim.lsp.protocol.Methods.textDocument_inlayHint, event.buf)
					then
						map("<leader>th", function()
							local is_enabled = vim.lsp.inlay_hint.is_enabled({ bufnr = event.buf })
							vim.lsp.inlay_hint.enable(not is_enabled, { bufnr = event.buf })
						end, "[T]oggle Inlay [H]ints")
					end
				end,
			})

			vim.diagnostic.config({
				severity_sort = true,
				float = { border = "rounded", source = "if_many" },
				underline = { severity = vim.diagnostic.severity.ERROR },
				signs = vim.g.have_nerd_font and {
					text = {
						[vim.diagnostic.severity.ERROR] = "󰅚 ",
						[vim.diagnostic.severity.WARN] = "󰀪 ",
						[vim.diagnostic.severity.INFO] = "󰋽 ",
						[vim.diagnostic.severity.HINT] = "󰌶 ",
					},
				} or {},
				virtual_text = {
					source = "if_many",
					spacing = 2,
					format = function(diagnostic)
						local diagnostic_message = {
							[vim.diagnostic.severity.ERROR] = diagnostic.message,
							[vim.diagnostic.severity.WARN] = diagnostic.message,
							[vim.diagnostic.severity.INFO] = diagnostic.message,
							[vim.diagnostic.severity.HINT] = diagnostic.message,
						}
						return diagnostic_message[diagnostic.severity]
					end,
				},
			})

			local capabilities = require("blink.cmp").get_lsp_capabilities()

			local eslint_config_files = {
				"eslint.config.js",
				"eslint.config.cjs",
				"eslint.config.mjs",
				"eslint.config.ts",
				"eslint.config.cts",
				"eslint.config.mts",
				".eslintrc",
				".eslintrc.js",
				".eslintrc.cjs",
				".eslintrc.mjs",
				".eslintrc.json",
				".eslintrc.yaml",
				".eslintrc.yml",
			}

			local function project_has_local_eslint(root_dir)
				local package_json = vim.fs.joinpath(root_dir, "package.json")
				if vim.fn.filereadable(package_json) == 0 then
					return false
				end

				local ok, package_data = pcall(vim.json.decode, table.concat(vim.fn.readfile(package_json), "\n"))
				if not ok or type(package_data) ~= "table" then
					return false
				end

				for _, field in ipairs({ "dependencies", "devDependencies", "optionalDependencies", "peerDependencies" }) do
					local deps = package_data[field]
					if type(deps) == "table" and deps.eslint then
						return true
					end
				end

				return false
			end

			local function resolve_python_path(root_dir, file_path)
				local python_subpath = is_windows and { ".venv", "Scripts", "python.exe" }
					or { ".venv", "bin", "python" }
				local venv_python_subpath = is_windows and { "Scripts", "python.exe" } or { "bin", "python" }

				local function executable_python_in(dir)
					if type(dir) ~= "string" or dir == "" then
						return nil
					end

					local python_path = vim.fs.joinpath(dir, tbl_unpack(python_subpath))
					if vim.fn.executable(python_path) == 1 then
						return python_path
					end

					return nil
				end

				local function executable_from_command(cmd, cwd)
					if vim.fn.executable(cmd[1]) ~= 1 then
						return nil
					end

					local result = vim.system(cmd, { cwd = cwd, text = true }):wait()
					if result.code ~= 0 then
						return nil
					end

					local python_path = vim.trim(result.stdout or "")
					if python_path ~= "" and vim.fn.executable(python_path) == 1 then
						return python_path
					end

					return nil
				end

				if type(root_dir) == "string" and root_dir ~= "" then
					local root_python = executable_python_in(root_dir)
					if root_python then
						return root_python
					end

					local current_dir = vim.fs.dirname(root_dir)
					while current_dir and current_dir ~= root_dir do
						local parent_python = executable_python_in(current_dir)
						if parent_python then
							return parent_python
						end

						local parent_dir = vim.fs.dirname(current_dir)
						if not parent_dir or parent_dir == current_dir then
							break
						end
						current_dir = parent_dir
					end

					if type(file_path) == "string" and file_path ~= "" then
						current_dir = vim.fs.dirname(file_path)
						while current_dir and current_dir ~= root_dir do
							local nested_python = executable_python_in(current_dir)
							if nested_python then
								return nested_python
							end

							local parent_dir = vim.fs.dirname(current_dir)
							if not parent_dir or parent_dir == current_dir then
								break
							end
							current_dir = parent_dir
						end
					end
				end

				local virtual_env = vim.env.VIRTUAL_ENV
				if type(virtual_env) == "string" and virtual_env ~= "" then
					local activated_python = vim.fs.joinpath(virtual_env, tbl_unpack(venv_python_subpath))
					if vim.fn.executable(activated_python) == 1 then
						return activated_python
					end
				end

				local command_cwd = type(root_dir) == "string" and root_dir ~= "" and root_dir or nil
				local uv_python = executable_from_command({ "uv", "python", "find" }, command_cwd)
				if uv_python then
					return uv_python
				end

				local mise_python = executable_from_command({ "mise", "which", "python" }, command_cwd)
				if mise_python then
					return mise_python
				end

				return nil
			end

			-- Add LSP servers here
			local servers = {
				clangd = {},
				eslint = {
					root_dir = function(bufnr, on_dir)
						local fname = vim.api.nvim_buf_get_name(bufnr)
						local root_dir = vim.fs.root(fname, eslint_config_files)
						if root_dir and project_has_local_eslint(root_dir) then
							on_dir(root_dir)
						end
					end,
				},
				gopls = {},
				pyright = {
					cmd = { "pyright-langserver", "--stdio" },
					filetypes = { "python" },
					root_markers = { "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", ".git" },
					single_file_support = true,
					before_init = function(_, config)
						local python_path = resolve_python_path(config.root_dir, vim.api.nvim_buf_get_name(0))
						if python_path then
							config.settings = config.settings or {}
							config.settings.python = config.settings.python or {}
							config.settings.python.pythonPath = python_path
						end
					end,
					root_dir = function(bufnr, on_dir)
						local fname = vim.api.nvim_buf_get_name(bufnr)
						local root_dir = vim.fs.root(
							fname,
							{ "pyproject.toml", "setup.py", "setup.cfg", "requirements.txt", ".git" }
						)
						on_dir(root_dir or vim.fs.dirname(fname))
					end,
					settings = {
						python = {},
					},
				},
				sourcekit = {
					filetypes = { "swift" },
				},
				ts_ls = {},
				rust_analyzer = {},
				zls = {},
				ols = {},
				lua_ls = {
					settings = {
						Lua = {
							completion = {
								callSnippet = "Replace",
							},
						},
					},
				},
			}

			local ensure_installed = {
				"clangd",
				"eslint-lsp",
				"gopls",
				"lua-language-server",
				"ols",
				"pyright",
				"prettier",
				"ruff",
				"rust-analyzer",
				"stylua",
				"tinymist",
				"typescript-language-server",
				"zls",
			}
			if not is_windows then
				table.insert(ensure_installed, "swiftformat")
			end
			require("mason-tool-installer").setup({ ensure_installed = ensure_installed })

			for server_name, server in pairs(servers) do
				server.capabilities = vim.tbl_deep_extend("force", {}, capabilities, server.capabilities or {})
				vim.lsp.config(server_name, server)
				vim.lsp.enable(server_name)
			end

			-- Set up ruff using vim.lsp.config (Neovim 0.11+)
			vim.lsp.config("ruff", {
				cmd = { "ruff", "server" },
				filetypes = { "python" },
				root_markers = { "pyproject.toml", "ruff.toml", ".ruff.toml", ".git" },
				init_options = {
					settings = {
						lint = {
							extendIgnore = { "F401", "F821" },
						},
					},
				},
			})
			vim.lsp.enable("ruff")

			-- Set up tinymist for Typst
			vim.lsp.config("tinymist", {
				cmd = { "tinymist" },
				filetypes = { "typst" },
				root_markers = { "typst.toml", ".git" },
			})
			vim.lsp.enable("tinymist")
		end,
	},

	{ -- Autoformat
		"stevearc/conform.nvim",
		event = { "BufWritePre" },
		cmd = { "ConformInfo" },
		keys = {
			{
				"<leader>f",
				function()
					require("conform").format({ async = true, lsp_format = "fallback" })
				end,
				mode = "",
				desc = "[F]ormat buffer",
			},
		},
		opts = {
			notify_on_error = false,
			format_on_save = function(bufnr)
				local disable_filetypes = { c = true, cpp = true }
				if disable_filetypes[vim.bo[bufnr].filetype] then
					return nil
				else
					return {
						timeout_ms = 3000,
						lsp_format = "fallback",
					}
				end
			end,
			formatters_by_ft = vim.tbl_extend("force", {
				javascript = { "prettier" },
				javascriptreact = { "prettier" },
				json = { "prettier" },
				lua = { "stylua" },
				python = { "ruff_format" },
				typescript = { "prettier" },
				typescriptreact = { "prettier" },
			}, is_windows and {} or {
				swift = { "swiftformat" },
			}),
		},
	},

	{ -- Autocompletion
		"saghen/blink.cmp",
		event = "VimEnter",
		version = "1.*",
		dependencies = {
			{
				"L3MON4D3/LuaSnip",
				version = "2.*",
				build = (function()
					if vim.fn.has("win32") == 1 or vim.fn.executable("make") == 0 then
						return
					end
					return "make install_jsregexp"
				end)(),
				dependencies = {},
				opts = {},
			},
			"folke/lazydev.nvim",
		},
		---@module 'blink.cmp'
		---@type blink.cmp.Config
		opts = {
			keymap = {
				preset = "default",
			},
			appearance = {
				nerd_font_variant = "mono",
			},
			completion = {
				documentation = { auto_show = false, auto_show_delay_ms = 500 },
			},
			sources = {
				default = { "lsp", "path", "snippets", "lazydev" },
				providers = {
					lazydev = { module = "lazydev.integrations.blink", score_offset = 100 },
				},
			},
			snippets = { preset = "luasnip" },
			fuzzy = { implementation = "lua" },
			signature = { enabled = true },
		},
	},

	{ -- Colorscheme
		"EdenEast/nightfox.nvim",
		priority = 1000,
		config = function()
			require("nightfox").setup({
				options = {
					styles = {
						comments = "NONE",
						keywords = "NONE",
						functions = "NONE",
					},
				},
			})
			vim.cmd.colorscheme("nordfox")

			-- Custom accent color overrides
			local accent = "#aaffff"
			vim.api.nvim_set_hl(0, "CursorLineNr", { fg = accent, bold = true })
			vim.api.nvim_set_hl(0, "MatchParen", { fg = accent, bold = true })
			vim.api.nvim_set_hl(0, "Search", { bg = "#3b4252", fg = accent })
			vim.api.nvim_set_hl(0, "IncSearch", { bg = accent, fg = "#2e3440" })
			vim.api.nvim_set_hl(0, "Visual", { bg = "#3b4252" })
			vim.api.nvim_set_hl(0, "TelescopeSelectionCaret", { fg = accent })
			vim.api.nvim_set_hl(0, "TelescopeMatching", { fg = accent })

			-- Make JSON/JSONC quotes same color as strings for readability
			vim.api.nvim_set_hl(0, "jsonQuote", { link = "String" })

			-- Highlight inline code in markdown (backtick text like `hello`)
			vim.api.nvim_set_hl(0, "@markup.raw.markdown_inline", { fg = "#ebcb8b" })
		end,
	},

	{
		"folke/todo-comments.nvim",
		event = "VimEnter",
		dependencies = { "nvim-lua/plenary.nvim" },
		opts = { signs = false },
	},

	{ -- Mini.nvim modules
		"echasnovski/mini.nvim",
		config = function()
			require("mini.ai").setup({ n_lines = 500 })
			require("mini.surround").setup()
			local statusline = require("mini.statusline")
			statusline.setup({ use_icons = vim.g.have_nerd_font })
			---@diagnostic disable-next-line: duplicate-set-field
			statusline.section_location = function()
				return "%2l:%-2v"
			end
		end,
	},

	{ -- Treesitter
		"nvim-treesitter/nvim-treesitter",
		build = ":TSUpdate",
		config = function()
			local parsers = {
				"bash",
				"c",
				"cpp",
				"diff",
				"go",
				"html",
				"javascript",
				"lua",
				"luadoc",
				"markdown",
				"markdown_inline",
				"python",
				"query",
				"rust",
				"sql",
				"typescript",
				"typst",
				"vim",
				"vimdoc",
				"zig",
				"odin",
				"swift",
			}

			-- Install missing parsers
			vim.api.nvim_create_autocmd("VimEnter", {
				once = true,
				callback = function()
					for _, lang in ipairs(parsers) do
						local ok = pcall(vim.treesitter.language.inspect, lang)
						if not ok then
							vim.cmd("TSInstall " .. lang)
						end
					end
				end,
			})

			-- C++20 module keyword highlights (deferred until cpp is first opened)
			vim.api.nvim_create_autocmd("FileType", {
				pattern = "cpp",
				once = true,
				callback = function()
					local files = vim.treesitter.query.get_files("cpp", "highlights")
					local parts = {}
					for _, file in ipairs(files) do
						local fh = io.open(file, "r")
						if fh then
							local content = fh:read("*a")
							fh:close()
							content = content:gsub(";%s*extends[^\n]*\n?", "")
							content = content:gsub(";%s*inherits[^\n]*\n?", "")
							table.insert(parts, content)
						end
					end
					table.insert(
						parts,
						[[
(module_declaration "module" @keyword.import)
(module_declaration "export" @keyword.import)
(import_declaration "import" @keyword.import)
(export_declaration "export" @keyword.import)
]]
					)
					pcall(vim.treesitter.query.set, "cpp", "highlights", table.concat(parts, "\n"))
				end,
			})

			-- Enable treesitter highlighting globally
			vim.api.nvim_create_autocmd("FileType", {
				callback = function(args)
					pcall(vim.treesitter.start, args.buf)
				end,
			})
		end,
	},

	{ -- Markdown preview in browser
		"iamcco/markdown-preview.nvim",
		ft = "markdown",
		build = "cd app && npm install",
		keys = {
			{ "<leader>mp", "<cmd>MarkdownPreviewToggle<CR>", desc = "[M]arkdown [P]review toggle" },
		},
	},

	{ -- Typst preview in browser
		"chomosuke/typst-preview.nvim",
		ft = "typst",
		build = function()
			require("typst-preview").update()
		end,
		keys = {
			{ "<leader>tp", "<cmd>TypstPreviewToggle<CR>", ft = "typst", desc = "[T]ypst [P]review toggle" },
		},
		opts = {},
	},

	-- Add plugins here
}, {
	ui = {
		icons = vim.g.have_nerd_font and {} or {
			cmd = "⌘",
			config = "🛠",
			event = "📅",
			ft = "📂",
			init = "⚙",
			keys = "🗝",
			plugin = "🔌",
			runtime = "💻",
			require = "🌙",
			source = "📄",
			start = "🚀",
			task = "📌",
			lazy = "💤 ",
		},
	},
})

-- vim: ts=2 sts=2 sw=2 et
